import type { Metadata } from 'next';
import { Cinzel, Inter } from 'next/font/google';
import './globals.css';
import { business, SITE_URL, openingHours } from '@/lib/data';

const cinzel = Cinzel({
  subsets: ['latin'],
  variable: '--font-cinzel',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: 'The Laundry Lounge | Boutique Garment, Footwear & Laundry Care',
  description:
    'Premium, eco-conscious garment, footwear and accessory care across the North West. Dry cleaning, footwear restoration, wash & fold and more. Book online in minutes.',
  keywords: [
    'laundry service',
    'dry cleaning',
    'footwear restoration',
    'trainer cleaning',
    'handbag cleaning',
    'ironing service',
    'wash and fold',
    'duvet cleaning',
    'Northwich laundry',
    'Cheshire dry cleaning',
    'The Laundry Lounge',
  ],
  authors: [{ name: business.name }],
  openGraph: {
    title: 'The Laundry Lounge | Boutique Garment, Footwear & Laundry Care',
    description:
      'Premium, eco-conscious garment, footwear and accessory care across the North West. Book online in minutes.',
    url: SITE_URL,
    siteName: business.name,
    type: 'website',
    locale: 'en_GB',
    images: [
      {
        url: '/og-image.jpg', // TODO: add a 1200x630 Open Graph image to /public
        width: 1200,
        height: 630,
        alt: 'The Laundry Lounge',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The Laundry Lounge | Boutique Garment, Footwear & Laundry Care',
    description:
      'Premium, eco-conscious garment, footwear and accessory care across the North West. Book online in minutes.',
    images: ['/og-image.jpg'], // TODO: add a 1200x630 Open Graph image to /public
  },
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: SITE_URL,
  },
};

const dayMap: Record<string, string> = {
  Monday: 'Monday',
  Tuesday: 'Tuesday',
  Wednesday: 'Wednesday',
  Thursday: 'Thursday',
  Friday: 'Friday',
  Saturday: 'Saturday',
  Sunday: 'Sunday',
};

const openingHoursSpecification = openingHours
  .filter((entry) => entry.hours !== 'Closed')
  .map(({ day, hours }) => {
    const [opens, closes] = hours.split('–').map((s) => s.trim());
    return {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: `https://schema.org/${dayMap[day]}`,
      opens: to24h(opens),
      closes: to24h(closes),
    };
  });

function to24h(time: string): string {
  const match = time.match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return '00:00';
  const [, h, m] = match;
  return `${h.padStart(2, '0')}:${m}`;
}

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'LocalBusiness',
  name: business.name,
  description:
    'Premium, eco-conscious garment, footwear and accessory care company offering dry cleaning, footwear restoration, wash & fold and household laundry across the North West.',
  url: SITE_URL,
  telephone: business.phone,
  email: business.email,
  address: {
    '@type': 'PostalAddress',
    streetAddress: business.address,
  },
  sameAs: [business.facebook, business.instagram],
  openingHoursSpecification,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${cinzel.variable} ${inter.variable}`}>
      <head>
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body className="font-body antialiased">{children}</body>
    </html>
  );
}
