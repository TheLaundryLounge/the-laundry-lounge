import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Highlights from '@/components/Highlights';
import About from '@/components/About';
import Services from '@/components/Services';
import Pricing from '@/components/Pricing';
import HowItWorks from '@/components/HowItWorks';
import Locations from '@/components/Locations';
import OpeningHours from '@/components/OpeningHours';
import BookCta from '@/components/BookCta';
import Contact from '@/components/Contact';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <>
      <Header />
      <main id="main-content">
        <Hero />
        <Highlights />
        <About />
        <Services />
        <Pricing />
        <HowItWorks />
        <Locations />
        <OpeningHours />
        <BookCta />
        <Contact />
        <FAQ />
      </main>
      <Footer />
    </>
  );
}
