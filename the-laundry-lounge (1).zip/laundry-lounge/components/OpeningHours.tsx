import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { openingHours } from '@/lib/data';
import { Clock } from 'lucide-react';

export default function OpeningHours() {
  return (
    <section id="opening-hours" className="bg-surface py-24 sm:py-28" aria-label="Opening hours">
      <Container>
        <div className="grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:items-center lg:gap-16">
          <Reveal as="div">
            <SectionHeading
              eyebrow="Opening Hours"
              title="Here whenever your week needs us"
              subtitle="Standard hours across our locations are below — individual drop-off points may vary slightly, so do check the location card if you're planning a specific visit."
            />
          </Reveal>

          <Reveal as="div" delay={120}>
            <div className="overflow-hidden rounded-3xl border border-line bg-white shadow-soft">
              <div className="flex items-center gap-2.5 border-b border-line bg-accent-50 px-6 py-4">
                <Clock className="h-[18px] w-[18px] text-accent" aria-hidden="true" />
                <span className="text-sm font-semibold uppercase tracking-wide text-accent">
                  Standard Opening Hours
                </span>
              </div>
              <div className="table-scroll overflow-x-auto">
                <table className="w-full min-w-[360px] border-collapse text-left">
                  <caption className="sr-only">The Laundry Lounge opening hours by day of the week</caption>
                  <thead>
                    <tr className="border-b border-line">
                      <th scope="col" className="px-6 py-3.5 text-sm font-semibold text-charcoal-soft">
                        Day
                      </th>
                      <th scope="col" className="px-6 py-3.5 text-sm font-semibold text-charcoal-soft">
                        Hours
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {openingHours.map(({ day, hours }, i) => (
                      <tr
                        key={day}
                        className={i !== openingHours.length - 1 ? 'border-b border-line' : ''}
                      >
                        <th scope="row" className="px-6 py-3.5 text-[15px] font-medium text-charcoal">
                          {day}
                        </th>
                        <td
                          className={`px-6 py-3.5 text-[15px] ${
                            hours === 'Closed' ? 'text-charcoal-soft' : 'text-charcoal'
                          }`}
                        >
                          {hours}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
