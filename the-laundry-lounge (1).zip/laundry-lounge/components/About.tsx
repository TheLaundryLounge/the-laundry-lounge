import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { AboutIllustration } from './Illustrations';
import { aboutPillars, aboutCopy, awards } from '@/lib/data';

export default function About() {
  return (
    <section id="about" className="relative bg-surface pb-24 pt-4 sm:pb-28" aria-labelledby="about-heading">
      <Container>
        <div className="grid items-center gap-14 lg:grid-cols-2 lg:gap-16">
          <Reveal as="div" className="order-2 lg:order-1">
            <SectionHeading
              eyebrow="About Us"
              title="Premium garment care, rooted in the North West"
            />
            <h3 id="about-heading" className="sr-only">
              About The Laundry Lounge
            </h3>

            <ul className="mt-7 flex flex-wrap gap-3">
              {aboutPillars.map(({ icon: Icon, label }) => (
                <li
                  key={label}
                  className="flex items-center gap-2 rounded-full border border-accent/20 bg-accent-50 px-4 py-2 text-sm font-semibold text-accent"
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                  {label}
                </li>
              ))}
            </ul>

            <p className="mt-7 max-w-xl text-base leading-relaxed text-charcoal-soft">
              {aboutCopy.intro}
            </p>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-charcoal-soft">
              {aboutCopy.detail}
            </p>

            <ul className="mt-7 space-y-2.5 border-t border-line pt-6">
              {awards.map(({ icon: Icon, label }) => (
                <li key={label} className="flex items-center gap-2.5 text-[15px] font-medium text-charcoal">
                  <Icon className="h-5 w-5 flex-shrink-0 text-accent" aria-hidden="true" />
                  {label}
                </li>
              ))}
            </ul>

            <p className="mt-7 font-display text-lg tracking-wide text-accent">
              {aboutCopy.tagline}
            </p>
          </Reveal>

          <Reveal as="div" delay={150} className="order-1 mx-auto w-full max-w-sm lg:order-2 lg:max-w-none">
            <AboutIllustration />
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
