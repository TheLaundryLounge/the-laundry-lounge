import Container from './ui/Container';
import { business } from '@/lib/data';
import { Waves, Facebook, Instagram } from 'lucide-react';

const footerLinks = [
  { href: '#about', label: 'About' },
  { href: '#services', label: 'Services' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#locations', label: 'Locations' },
  { href: '#faq', label: 'FAQ' },
];

const legalLinks = [
  { href: '/privacy-policy', label: 'Privacy Policy' }, // TODO: link to real privacy policy page
  { href: '/terms-and-conditions', label: 'Terms & Conditions' }, // TODO: link to real terms page
];

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-charcoal py-16 text-white/70">
      <Container>
        <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <a href="#top" className="flex items-center gap-2.5 font-display text-lg font-medium text-white">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-white">
                <Waves className="h-5 w-5" aria-hidden="true" />
              </span>
              {business.name}
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/55">
              Premium, eco-conscious garment, footwear and accessory care across the
              North West. Powered by Clean Kickz Club, part of Terry &amp; Co.
            </p>
          </div>

          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-white">Explore</h2>
            <ul className="mt-4 space-y-3">
              {footerLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-sm transition-colors hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-white">Legal</h2>
            <ul className="mt-4 space-y-3">
              {legalLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-sm transition-colors hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-white">Follow</h2>
            <div className="mt-4 flex items-center gap-3">
              <a
                href={business.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="The Laundry Lounge on Facebook"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 transition-all hover:-translate-y-0.5 hover:border-white/40 hover:text-white"
              >
                <Facebook className="h-[18px] w-[18px]" aria-hidden="true" />
              </a>
              <a
                href={business.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="The Laundry Lounge on Instagram"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 transition-all hover:-translate-y-0.5 hover:border-white/40 hover:text-white"
              >
                <Instagram className="h-[18px] w-[18px]" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-14 border-t border-white/10 pt-8 text-sm text-white/50">
          &copy; {year} {business.name}. All rights reserved.
        </div>
      </Container>
    </footer>
  );
}
