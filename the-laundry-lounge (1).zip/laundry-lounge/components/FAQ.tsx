import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { faqs } from '@/lib/data';
import { ChevronDown } from 'lucide-react';

export default function FAQ() {
  return (
    <section id="faq" className="bg-surface py-24 sm:py-28" aria-labelledby="faq-heading">
      <Container>
        <SectionHeading
          eyebrow="FAQ"
          title="Questions we hear a lot"
          align="center"
        />
        <h3 id="faq-heading" className="sr-only">
          Frequently asked questions
        </h3>

        <div className="mx-auto mt-14 max-w-3xl divide-y divide-line rounded-3xl border border-line bg-white">
          {faqs.map(({ question, answer }, i) => (
            <Reveal as="div" delay={i * 50} key={question}>
              <details className="group px-6 py-1 sm:px-8">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-left text-[16px] font-medium text-charcoal marker:content-none">
                  {question}
                  <ChevronDown
                    className="faq-chevron h-5 w-5 flex-shrink-0 text-accent transition-transform duration-300"
                    aria-hidden="true"
                  />
                </summary>
                <p className="pb-6 pr-8 text-[15px] leading-relaxed text-charcoal-soft">
                  {answer}
                </p>
              </details>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
