type SectionHeadingProps = {
  eyebrow: string;
  title: string;
  subtitle?: string;
  align?: 'left' | 'center';
  light?: boolean;
};

export default function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = 'left',
  light = false,
}: SectionHeadingProps) {
  const alignment = align === 'center' ? 'items-center text-center mx-auto' : 'items-start text-left';

  return (
    <div className={`flex flex-col gap-4 ${alignment} max-w-2xl`}>
      <span
        className={`inline-flex items-center rounded-full border px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] ${
          light
            ? 'border-white/25 text-white/90'
            : 'border-accent/20 bg-accent-50 text-accent'
        }`}
      >
        {eyebrow}
      </span>
      <h2
        className={`font-display text-3xl sm:text-4xl lg:text-[2.75rem] font-medium leading-[1.2] tracking-wide ${
          light ? 'text-white' : 'text-charcoal'
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p className={`text-base sm:text-lg leading-relaxed ${light ? 'text-white/80' : 'text-charcoal-soft'}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
