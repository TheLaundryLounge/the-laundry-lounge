import { ReactNode } from 'react';
import { ArrowRight } from 'lucide-react';

type ButtonProps = {
  href: string;
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'inverse';
  size?: 'md' | 'lg';
  external?: boolean;
  icon?: boolean;
  className?: string;
};

export default function Button({
  href,
  children,
  variant = 'primary',
  size = 'md',
  external = false,
  icon = true,
  className = '',
}: ButtonProps) {
  const base =
    'group inline-flex items-center justify-center gap-2 rounded-full font-body font-semibold transition-all duration-300 ease-out focus-visible:outline-2 focus-visible:outline-accent';

  const sizes = {
    md: 'px-6 py-3 text-[15px]',
    lg: 'px-8 py-4 text-base',
  };

  const variants = {
    primary:
      'bg-accent text-white shadow-soft hover:bg-accent-dark hover:shadow-lift hover:-translate-y-0.5 active:translate-y-0',
    secondary:
      'bg-white text-charcoal border border-line hover:border-accent/40 hover:text-accent hover:-translate-y-0.5 active:translate-y-0',
    inverse:
      'bg-white text-accent hover:bg-accent-light hover:-translate-y-0.5 active:translate-y-0',
  };

  const props = external
    ? { target: '_blank', rel: 'noopener noreferrer' }
    : {};

  return (
    <a
      href={href}
      className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}
      {...props}
    >
      {children}
      {icon && (
        <ArrowRight
          className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
          aria-hidden="true"
        />
      )}
    </a>
  );
}
