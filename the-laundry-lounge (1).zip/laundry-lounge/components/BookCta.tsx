import Container from './ui/Container';
import Button from './ui/Button';
import Reveal from './ui/Reveal';
import { GOOGLE_FORM_URL } from '@/lib/data';

export default function BookCta() {
  return (
    <section id="book" className="relative overflow-hidden bg-accent py-20 sm:py-24" aria-labelledby="book-heading">
      <div
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-32 -left-16 h-72 w-72 rounded-full bg-white/10 blur-3xl"
        aria-hidden="true"
      />
      <Container className="relative">
        <Reveal as="div" className="mx-auto flex max-w-2xl flex-col items-center gap-6 text-center">
          <span className="inline-flex items-center rounded-full border border-white/25 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-white/90">
            Ready when you are
          </span>
          <h2 id="book-heading" className="font-display text-3xl font-medium leading-tight text-white sm:text-4xl">
            Let&apos;s take laundry off your to-do list
          </h2>
          <p className="text-lg leading-relaxed text-white/85">
            Booking takes less than two minutes. Tell us what you need, choose a
            drop-off location, and we&apos;ll handle the rest.
          </p>
          <Button href={GOOGLE_FORM_URL} external variant="inverse" size="lg" className="mt-2">
            Book Now
          </Button>
        </Reveal>
      </Container>
    </section>
  );
}
