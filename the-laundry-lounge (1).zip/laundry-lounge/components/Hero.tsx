import Container from './ui/Container';
import Button from './ui/Button';
import Reveal from './ui/Reveal';
import { HeroIllustration, WaveDivider } from './Illustrations';
import { GOOGLE_FORM_URL } from '@/lib/data';

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-white pt-14 sm:pt-20 lg:pt-24" aria-label="Introduction">
      <Container>
        <div className="grid items-center gap-14 lg:grid-cols-2 lg:gap-10">
          <Reveal as="div" className="max-w-xl">
            <span className="inline-flex items-center rounded-full border border-accent/20 bg-accent-50 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-accent">
              Boutique garment &amp; laundry care
            </span>
            <h1 className="mt-6 font-display text-4xl font-medium leading-[1.15] tracking-wide text-charcoal sm:text-5xl lg:text-[3.2rem]">
              Keeping the planet <span className="text-accent">green</span>, and your laundry <span className="text-accent">clean</span>
            </h1>
            <p className="mt-6 text-lg leading-relaxed text-charcoal-soft">
              A premium, eco-conscious garment, footwear and accessory care company —
              refining the traditional dry-cleaning experience with a boutique-style
              service, across the North West.
            </p>
            <div className="mt-9 flex flex-col gap-3.5 sm:flex-row">
              <Button href={GOOGLE_FORM_URL} external size="lg">
                Book Now
              </Button>
              <Button href="#services" variant="secondary" size="lg" icon={false}>
                View Services
              </Button>
            </div>
          </Reveal>

          <Reveal as="div" delay={150} className="relative mx-auto w-full max-w-md lg:max-w-none">
            <div className="animate-float">
              <HeroIllustration />
            </div>
          </Reveal>
        </div>
      </Container>

      <div className="mt-16 sm:mt-20 lg:mt-24">
        <WaveDivider color="#F6F4FB" />
      </div>
    </section>
  );
}
