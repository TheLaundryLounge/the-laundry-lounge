import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { ContactIllustration } from './Illustrations';
import { business } from '@/lib/data';
import { Phone, Mail, Facebook, Instagram, MapPin } from 'lucide-react';

const contactItems = [
  { icon: Phone, label: 'Phone', value: business.phone, href: `tel:${business.phone.replace(/\s+/g, '')}` },
  { icon: Mail, label: 'Email', value: business.email, href: `mailto:${business.email}` },
  { icon: MapPin, label: 'Address', value: business.address, href: undefined },
];

export default function Contact() {
  return (
    <section id="contact" className="bg-white py-24 sm:py-28" aria-labelledby="contact-heading">
      <Container>
        <div className="grid gap-14 lg:grid-cols-2 lg:gap-16">
          <Reveal as="div">
            <SectionHeading
              eyebrow="Contact"
              title="Come and say hello"
              subtitle="Got a question before you book? Reach out however suits you best — we're always happy to help."
            />
            <h3 id="contact-heading" className="sr-only">
              Contact The Laundry Lounge
            </h3>

            <dl className="mt-8 space-y-5">
              {contactItems.map(({ icon: Icon, label, value, href }) => (
                <div key={label} className="flex items-start gap-4">
                  <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-2xl bg-accent-light text-accent">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <div>
                    <dt className="text-sm font-medium text-charcoal-soft">{label}</dt>
                    <dd className="mt-0.5 text-[15px] font-medium text-charcoal">
                      {href ? (
                        <a href={href} className="transition-colors hover:text-accent">
                          {value}
                        </a>
                      ) : (
                        value
                      )}
                    </dd>
                  </div>
                </div>
              ))}
            </dl>

            <div className="mt-8 flex items-center gap-3">
              <a
                href={business.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="The Laundry Lounge on Facebook"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-charcoal transition-all hover:-translate-y-0.5 hover:border-accent/40 hover:text-accent"
              >
                <Facebook className="h-5 w-5" aria-hidden="true" />
              </a>
              <a
                href={business.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="The Laundry Lounge on Instagram"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-charcoal transition-all hover:-translate-y-0.5 hover:border-accent/40 hover:text-accent"
              >
                <Instagram className="h-5 w-5" aria-hidden="true" />
              </a>
            </div>
          </Reveal>

          <Reveal as="div" delay={120} className="mx-auto w-full max-w-sm lg:max-w-none">
            <div className="overflow-hidden rounded-4xl bg-surface p-8">
              <ContactIllustration />
            </div>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
