// Custom, on-brand SVG illustrations for The Laundry Lounge.
// Kept as inline components (no external image requests) so the page stays
// fast, crisp at any size, and easy to recolour from one place.

export function HeroIllustration() {
  return (
    <svg
      viewBox="0 0 480 480"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="h-full w-full"
      role="img"
      aria-label="Illustration of a folded shirt resting beside a laundry basket with soft bubbles"
    >
      <circle cx="240" cy="240" r="220" fill="#F5F1FC" />
      <circle cx="240" cy="240" r="220" fill="url(#hero-radial)" fillOpacity="0.6" />
      {/* laundry basket */}
      <rect x="120" y="270" width="220" height="130" rx="24" fill="#EDE6FA" />
      <path
        d="M120 294c0-13.3 10.7-24 24-24h172c13.3 0 24 10.7 24 24v10H120v-10Z"
        fill="#5019AF"
      />
      {Array.from({ length: 7 }).map((_, i) => (
        <line
          key={i}
          x1={140 + i * 30}
          y1="270"
          x2={140 + i * 30}
          y2="400"
          stroke="#D9CCF2"
          strokeWidth="4"
          strokeLinecap="round"
        />
      ))}
      {/* folded shirt on top */}
      <g transform="translate(150 150)">
        <path
          d="M20 30 60 10c8 14 30 14 38 0l40 20-16 26-14-6v92c0 6-5 11-11 11H61c-6 0-11-5-11-11v-92l-14 6-16-26Z"
          fill="#FFFFFF"
          stroke="#5019AF"
          strokeWidth="6"
          strokeLinejoin="round"
        />
        <path d="M60 10c8 14 30 14 38 0" stroke="#5019AF" strokeWidth="6" strokeLinecap="round" />
      </g>
      {/* bubbles */}
      <circle cx="352" cy="120" r="14" fill="#5019AF" fillOpacity="0.18" />
      <circle cx="378" cy="150" r="8" fill="#5019AF" fillOpacity="0.28" />
      <circle cx="100" cy="110" r="10" fill="#5019AF" fillOpacity="0.22" />
      <circle cx="336" cy="330" r="9" fill="#5019AF" fillOpacity="0.25" />
      <defs>
        <radialGradient id="hero-radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(240 180) rotate(90) scale(240)">
          <stop stopColor="#EDE6FA" />
          <stop offset="1" stopColor="#F6F4FB" stopOpacity="0" />
        </radialGradient>
      </defs>
    </svg>
  );
}

export function AboutIllustration() {
  return (
    <svg
      viewBox="0 0 420 420"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="h-full w-full"
      role="img"
      aria-label="Illustration of neatly stacked folded towels"
    >
      <rect x="20" y="20" width="380" height="380" rx="32" fill="#F6F4FB" />
      <g transform="translate(90 80)">
        <rect x="0" y="180" width="240" height="34" rx="10" fill="#5019AF" />
        <rect x="10" y="130" width="220" height="34" rx="10" fill="#7A44D1" />
        <rect x="0" y="80" width="240" height="34" rx="10" fill="#5019AF" />
        <rect x="10" y="30" width="220" height="34" rx="10" fill="#EDE6FA" stroke="#5019AF" strokeWidth="3" />
        <rect x="0" y="-20" width="240" height="34" rx="10" fill="#F5F1FC" stroke="#5019AF" strokeWidth="3" />
      </g>
      <circle cx="340" cy="80" r="10" fill="#5019AF" fillOpacity="0.25" />
      <circle cx="70" cy="340" r="14" fill="#5019AF" fillOpacity="0.18" />
    </svg>
  );
}

export function ContactIllustration() {
  return (
    <svg
      viewBox="0 0 320 260"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="h-full w-full"
      role="img"
      aria-label="Illustration of a location pin marking a storefront"
    >
      <rect x="10" y="60" width="300" height="150" rx="16" fill="#F6F4FB" />
      <rect x="40" y="100" width="60" height="110" rx="6" fill="#FFFFFF" stroke="#5019AF" strokeWidth="4" />
      <rect x="130" y="100" width="60" height="60" rx="6" fill="#EDE6FA" stroke="#5019AF" strokeWidth="4" />
      <rect x="220" y="100" width="60" height="110" rx="6" fill="#FFFFFF" stroke="#5019AF" strokeWidth="4" />
      <path
        d="M160 10c-24 0-44 19-44 43 0 32 44 78 44 78s44-46 44-78c0-24-20-43-44-43Z"
        fill="#5019AF"
      />
      <circle cx="160" cy="53" r="16" fill="#FFFFFF" />
    </svg>
  );
}

export function WaveDivider({ flip = false, color = '#F6F4FB' }: { flip?: boolean; color?: string }) {
  return (
    <div className={`w-full leading-[0] ${flip ? 'rotate-180' : ''}`} aria-hidden="true">
      <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
        <path
          d="M0 32C240 72 480 8 720 24C960 40 1200 72 1440 32V80H0V32Z"
          fill={color}
        />
      </svg>
    </div>
  );
}
