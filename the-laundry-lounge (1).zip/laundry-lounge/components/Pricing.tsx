import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { pricingCategories, collectionInfo } from '@/lib/data';
import { ChevronDown, Truck, HelpCircle } from 'lucide-react';
import PricingAutoOpen from './PricingAutoOpen';

export default function Pricing() {
  return (
    <section id="pricing" className="bg-surface py-24 sm:py-28" aria-labelledby="pricing-heading">
      <PricingAutoOpen />
      <Container>
        <SectionHeading
          eyebrow="Pricing"
          title="Clear, upfront pricing for every item"
          subtitle="Browse our full price list by category below. If you're unsure which category your item falls under, just ask — we're happy to help."
        />
        <h3 id="pricing-heading" className="sr-only">
          The Laundry Lounge price list
        </h3>

        <div className="mx-auto mt-14 max-w-4xl divide-y divide-line rounded-3xl border border-line bg-white">
          {pricingCategories.map(({ id, name, items }, i) => (
            <Reveal as="div" delay={i * 40} key={id}>
              <details id={`pricing-${id}`} className="group scroll-mt-24 px-6 py-1 sm:px-8" open={i === 0}>
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-left marker:content-none">
                  <span className="font-display text-lg tracking-wide text-charcoal">{name}</span>
                  <ChevronDown
                    className="faq-chevron h-5 w-5 flex-shrink-0 text-accent transition-transform duration-300"
                    aria-hidden="true"
                  />
                </summary>
                <ul className="grid gap-x-8 gap-y-3 pb-7 sm:grid-cols-2">
                  {items.map(({ name: itemName, price }) => (
                    <li
                      key={itemName}
                      className="flex items-baseline justify-between gap-4 border-b border-dashed border-line pb-2 text-[15px]"
                    >
                      <span className="text-charcoal">{itemName}</span>
                      <span className="whitespace-nowrap font-semibold text-accent">{price}</span>
                    </li>
                  ))}
                </ul>
              </details>
            </Reveal>
          ))}
        </div>

        <div className="mx-auto mt-8 grid max-w-4xl gap-4 sm:grid-cols-2">
          <div className="flex items-start gap-3 rounded-2xl border border-line bg-white p-5">
            <Truck className="mt-0.5 h-5 w-5 flex-shrink-0 text-accent" aria-hidden="true" />
            <div>
              <p className="text-[15px] font-semibold text-charcoal">{collectionInfo.local}</p>
              <p className="mt-0.5 text-sm text-charcoal-soft">{collectionInfo.remote}</p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-2xl border border-line bg-white p-5">
            <HelpCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-accent" aria-hidden="true" />
            <p className="text-[15px] text-charcoal-soft">{collectionInfo.specialRequest}</p>
          </div>
        </div>
      </Container>
    </section>
  );
}
