import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { locations, business } from '@/lib/data';
import { MapPin, Store, Users, ArrowUpRight } from 'lucide-react';

export default function Locations() {
  return (
    <section id="locations" className="bg-white py-24 sm:py-28" aria-labelledby="locations-heading">
      <Container>
        <SectionHeading
          eyebrow="Drop-Off Locations"
          title="Find your nearest Laundry Lounge hub"
          subtitle="Drop off and collect at our Northwich store or any of our partner hubs across the North West — all free within a 7 mile radius."
        />
        <h3 id="locations-heading" className="sr-only">
          The Laundry Lounge drop-off locations
        </h3>

        <ul className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {locations.map(({ name, address, type, mapsUrl }, i) => (
            <Reveal as="li" delay={i * 70} key={name} className="h-full">
              <div className="flex h-full flex-col rounded-3xl border border-line bg-surface p-7 transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
                <div className="flex items-center justify-between">
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-accent shadow-soft">
                    <MapPin className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
                      type === 'store' ? 'bg-accent text-white' : 'bg-white text-charcoal-soft'
                    }`}
                  >
                    {type === 'store' ? (
                      <>
                        <Store className="h-3.5 w-3.5" aria-hidden="true" /> Our store
                      </>
                    ) : (
                      <>
                        <Users className="h-3.5 w-3.5" aria-hidden="true" /> Partner hub
                      </>
                    )}
                  </span>
                </div>
                <h4 className="mt-5 font-display text-lg tracking-wide text-charcoal">{name}</h4>
                <p className="mt-1.5 text-[15px] text-charcoal-soft">{address}</p>

                <p className="mt-5 border-t border-line pt-5 text-[13px] leading-relaxed text-charcoal-soft">
                  {type === 'store'
                    ? 'See our full opening hours below.'
                    : 'Drop off during this hub\u2019s normal opening hours.'}
                </p>

                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 inline-flex items-center gap-1.5 text-[15px] font-semibold text-accent transition-colors hover:text-accent-dark"
                >
                  Get directions
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
              </div>
            </Reveal>
          ))}
        </ul>

        <p className="mt-10 text-center text-[15px] text-charcoal-soft">
          Prefer to visit in person? Come and see us at {business.address}.
        </p>
      </Container>
    </section>
  );
}
