'use client';

import { useEffect, useState } from 'react';
import { Menu, X, Waves } from 'lucide-react';
import Container from './ui/Container';
import Button from './ui/Button';
import { GOOGLE_FORM_URL, business } from '@/lib/data';

const navLinks = [
  { href: '#about', label: 'About' },
  { href: '#services', label: 'Services' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#how-it-works', label: 'How It Works' },
  { href: '#locations', label: 'Locations' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contact', label: 'Contact' },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? 'bg-white/90 shadow-soft backdrop-blur-md' : 'bg-white/70 backdrop-blur-sm'
      }`}
    >
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-accent focus:px-4 focus:py-2 focus:text-white"
      >
        Skip to content
      </a>
      <Container>
        <div className="flex h-20 items-center justify-between">
          <a href="#top" className="flex items-center gap-2.5 font-display text-xl font-medium text-charcoal">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-white">
              <Waves className="h-5 w-5" aria-hidden="true" />
            </span>
            {business.name}
          </a>

          <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-[15px] font-medium text-charcoal-soft transition-colors hover:text-accent"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="hidden lg:block">
            <Button href={GOOGLE_FORM_URL} external size="md">
              Book Now
            </Button>
          </div>

          <button
            type="button"
            className="inline-flex items-center justify-center rounded-full p-2 text-charcoal lg:hidden"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </Container>

      <div
        id="mobile-menu"
        className={`grid overflow-hidden bg-white transition-[grid-template-rows] duration-300 ease-out lg:hidden ${
          open ? 'grid-rows-[1fr] border-t border-line' : 'grid-rows-[0fr]'
        }`}
      >
        <div className="min-h-0">
          <Container>
            <nav className="flex flex-col gap-1 py-4" aria-label="Mobile">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="rounded-xl px-3 py-3 text-[15px] font-medium text-charcoal transition-colors hover:bg-surface hover:text-accent"
                >
                  {link.label}
                </a>
              ))}
              <div className="mt-2 px-3 pb-2">
                <Button href={GOOGLE_FORM_URL} external size="md" className="w-full">
                  Book Now
                </Button>
              </div>
            </nav>
          </Container>
        </div>
      </div>
    </header>
  );
}
