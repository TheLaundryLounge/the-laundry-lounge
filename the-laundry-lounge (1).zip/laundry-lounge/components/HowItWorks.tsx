import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { steps } from '@/lib/data';

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-surface py-24 sm:py-28" aria-labelledby="how-heading">
      <Container>
        <SectionHeading
          eyebrow="How It Works"
          title="Four simple steps, start to finish"
          align="center"
        />
        <h3 id="how-heading" className="sr-only">
          How The Laundry Lounge process works
        </h3>

        <ol className="relative mt-16 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {/* connecting line, desktop only */}
          <div className="pointer-events-none absolute left-0 right-0 top-8 hidden h-px bg-line lg:block" aria-hidden="true" />

          {steps.map(({ icon: Icon, title, description }, i) => (
            <Reveal as="li" delay={i * 80} key={title} className="relative flex flex-col items-center text-center lg:items-center">
              <div className="relative z-10 flex h-16 w-16 items-center justify-center rounded-full bg-white shadow-soft ring-8 ring-surface">
                <Icon className="h-7 w-7 text-accent" aria-hidden="true" />
              </div>
              <span className="mt-5 font-display text-sm font-semibold text-accent">
                Step {i + 1}
              </span>
              <h4 className="mt-1.5 font-display text-lg font-medium text-charcoal">{title}</h4>
              <p className="mt-2 max-w-[16rem] text-[15px] leading-relaxed text-charcoal-soft">
                {description}
              </p>
            </Reveal>
          ))}
        </ol>
      </Container>
    </section>
  );
}
