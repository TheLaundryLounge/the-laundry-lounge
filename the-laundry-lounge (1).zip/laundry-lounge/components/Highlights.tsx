import Container from './ui/Container';
import Reveal from './ui/Reveal';
import { highlights } from '@/lib/data';

export default function Highlights() {
  return (
    <section className="bg-white py-16 sm:py-20" aria-label="Why choose The Laundry Lounge">
      <Container>
        <ul className="grid gap-6 sm:grid-cols-3">
          {highlights.map(({ icon: Icon, title, description }, i) => (
            <Reveal as="li" delay={i * 70} key={title}>
              <div className="flex h-full flex-col items-start gap-3 rounded-3xl border border-line bg-surface p-6">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-accent-light text-accent">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <p className="font-display text-base tracking-wide text-charcoal">{title}</p>
                <p className="text-[15px] leading-relaxed text-charcoal-soft">{description}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </Container>
    </section>
  );
}
