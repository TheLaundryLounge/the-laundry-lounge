import Container from './ui/Container';
import Reveal from './ui/Reveal';
import SectionHeading from './ui/SectionHeading';
import { services } from '@/lib/data';
import { ArrowUpRight } from 'lucide-react';

export default function Services() {
  return (
    <section id="services" className="bg-white py-24 sm:py-28" aria-labelledby="services-heading">
      <Container>
        <SectionHeading
          eyebrow="Our Services"
          title="Everything your wardrobe needs, handled properly"
          subtitle="From everyday washing to specialist footwear restoration, pick exactly what you need — we'll take care of the rest."
        />

        <h3 id="services-heading" className="sr-only">
          Services offered by The Laundry Lounge
        </h3>

        <ul className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ icon: Icon, name, description, price, categoryId }, i) => (
            <Reveal as="li" delay={i * 60} key={name} className="h-full">
              <div className="flex h-full flex-col rounded-3xl border border-line bg-white p-7 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
                <div className="flex items-start justify-between gap-4">
                  <span className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-accent-light text-accent">
                    <Icon className="h-6 w-6" aria-hidden="true" />
                  </span>
                  <span className="whitespace-nowrap rounded-full bg-surface px-3 py-1.5 text-sm font-semibold text-charcoal">
                    {price}
                  </span>
                </div>
                <h4 className="mt-5 font-display text-lg tracking-wide text-charcoal">{name}</h4>
                <p className="mt-2.5 flex-1 text-[15px] leading-relaxed text-charcoal-soft">{description}</p>
                <a
                  href={`#pricing-${categoryId}`}
                  className="mt-5 inline-flex items-center gap-1.5 text-[14px] font-semibold text-accent transition-colors hover:text-accent-dark"
                >
                  See full pricing
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </Reveal>
          ))}
        </ul>
      </Container>
    </section>
  );
}
