// ---------------------------------------------------------------------------
// The Laundry Lounge — site content
// Edit the values in this file to update copy, prices, locations and links
// across the whole website. Nothing else needs to change.
// ---------------------------------------------------------------------------

import {
  Shirt,
  WashingMachine,
  Footprints,
  Gem,
  BedDouble,
  Home,
  ClipboardList,
  MapPinned,
  PackageCheck,
  Wind,
  Zap,
  Leaf,
  Heart,
  Trophy,
  Award,
} from 'lucide-react';

export const GOOGLE_FORM_URL =
  'https://docs.google.com/forms/d/1R-bEB215FK6tZ1LWfq8jAU03zBDMsOn6lIp2Ip08Guw/viewform?edit_requested=true';

export const SITE_URL = 'https://www.thelaundrylounge.co.uk'; // TODO: replace with your live domain

export const business = {
  name: 'The Laundry Lounge',
  tagline: 'Keeping the planet clean, and your garments clean',
  phone: '07494 110 310',
  email: 'thelaundryloungecheshire@gmail.com',
  address: '109 Witton St, Northwich, CW9 5DY',
  facebook: 'https://www.facebook.com/thelaundryloungeuk', // TODO: confirm exact Facebook page URL ("The Laundry Lounge")
  instagram: 'https://instagram.com/thelaundryloungeuk',
};

// -- About section content ---------------------------------------------------

export const aboutPillars = [
  { icon: Gem, label: 'Quality Care' },
  { icon: Wind, label: 'Spotless Results' },
  { icon: Leaf, label: 'Sustainable Choices' },
];

export const aboutCopy = {
  intro:
    'The Laundry Lounge is a modern, eco-conscious garment and accessory care company, redefining the traditional dry-cleaning experience with a premium boutique-style service. Powered by Clean Kickz Club and part of Terry & Co, we specialise in cleaning, restoring and maintaining garments, footwear and accessories for professionals, families and fashion-conscious customers across the North West.',
  detail:
    'Using high-grade equipment and eco-friendly detergents, we help extend the life of clothing and footwear while reducing textile waste and landfill pollution. With convenient online booking, order tracking and partner drop-off locations across the region, we make premium garment care simple and accessible.',
  tagline: 'Keeping the planet green and your laundry clean.',
};

export const awards = [
  { icon: Trophy, label: 'Winner, 2025 Global Recognition Awards' },
  { icon: Award, label: 'Ranked 4th, Best Small Business Awards 2025' },
];

export const highlights = [
  {
    icon: Zap,
    title: 'Fast turnaround',
    description: 'Quick, reliable service to fit your lifestyle.',
  },
  {
    icon: Leaf,
    title: 'We care about our planet',
    description: 'Eco-friendly products and sustainable practices for a cleaner tomorrow.',
  },
  {
    icon: Heart,
    title: 'Passion for your belongings',
    description: 'Every garment, bag and pair of shoes is treated with real care and attention.',
  },
];

// -- Services (overview cards, link through to full price list) -------------

export const services = [
  {
    icon: Shirt,
    name: 'Garments & Dry Cleaning',
    categoryId: 'garments',
    description:
      'Suits, coats, dresses and everyday wear, cleaned and pressed the way the label recommends.',
    price: 'From £2.00',
  },
  {
    icon: Footprints,
    name: 'Footwear Restoration',
    categoryId: 'footwear',
    description:
      'Trainers, boots and designer footwear cleaned and restored — from everyday sports shoes to statement pairs.',
    price: 'From £20.00',
  },
  {
    icon: Gem,
    name: 'Accessories & Bags',
    categoryId: 'accessories',
    description:
      'Handbags, belts, scarves and headwear given a deep clean that keeps them looking their best for longer.',
    price: 'From £9.00',
  },
  {
    icon: BedDouble,
    name: 'Linen & Bedding',
    categoryId: 'linen-bedding',
    description:
      'Duvets, bed sets, towels and pillowcases refreshed and deep-cleaned, so your bed feels as good as it looks.',
    price: 'From £1.50',
  },
  {
    icon: Home,
    name: 'Upholstery & Home',
    categoryId: 'upholstery',
    description:
      'Rugs, curtains, cushion covers and prams — the bulky household items, taken care of properly.',
    price: 'From £6.00',
  },
  {
    icon: WashingMachine,
    name: 'Wash, Dry & Fold',
    categoryId: 'services',
    description:
      'Everyday laundry handled from start to finish — sorted, washed with care, dried and folded ready to put away.',
    price: 'From £20.00',
  },
];

// -- Full price list, grouped by category ------------------------------------

export const pricingCategories = [
  {
    id: 'accessories',
    name: 'Accessories',
    items: [
      { name: 'Belt', price: '£10.00' },
      { name: 'Handbag deep clean (large)', price: '£55.00' },
      { name: 'Handbag deep clean (medium)', price: '£45.00' },
      { name: 'Handbag deep clean (small)', price: '£35.00' },
      { name: 'Scarf', price: '£9.00' },
      { name: 'Wallet / purse', price: '£18.00' },
      { name: 'Headwear (Standard)', price: '£25.00' },
      { name: 'Headwear (Designer)', price: '£35.00' },
    ],
  },
  {
    id: 'footwear',
    name: 'Footwear',
    items: [
      { name: 'Adult (designer)', price: '£50.00+' },
      { name: 'Adult (sport)', price: '£40.00+' },
      { name: 'Junior (designer)', price: '£30.00+' },
      { name: 'Junior (sport)', price: '£20.00+' },
      { name: 'Walking boots (Timberlands)', price: '£35.00+' },
      { name: 'Apparel (Converse / Vans)', price: '£25.00' },
      { name: 'Ugg boots', price: '£35.00' },
      { name: 'Kids Uggs', price: '£25.00' },
      { name: 'Sandals / Birkenstocks', price: '£25.00' },
      { name: 'High heels', price: '£25.00' },
    ],
  },
  {
    id: 'linen-bedding',
    name: 'Linen / Bedding',
    items: [
      { name: 'Bed set (single)', price: '£11.50' },
      { name: 'Bed set (king & double)', price: '£15.00' },
      { name: 'Pillowcases', price: '£1.50' },
      { name: 'Duvet cover / sheet', price: '£7.50' },
      { name: 'Towel (small)', price: '£1.50' },
      { name: 'Towel (medium)', price: '£3.50' },
      { name: 'Towel (large)', price: '£5.00' },
      { name: 'Duvet (Single)', price: '£21.00' },
      { name: 'Duvet (Double)', price: '£23.00' },
      { name: 'Duvet (King)', price: '£25.00' },
    ],
  },
  {
    id: 'upholstery',
    name: 'Upholstery',
    items: [
      { name: 'Cushion cover', price: '£6.00' },
      { name: 'Door mats (large)', price: '£10.00' },
      { name: 'Door mats (medium)', price: '£8.00' },
      { name: 'Door mats (small)', price: '£6.00' },
      { name: 'Pram (half clean)', price: '£50.00' },
      { name: 'Pram (full clean)', price: '£110.00' },
      { name: 'Ruggable rugs (>45.5")', price: '£65.00' },
      { name: 'Ruggable rugs (31.5"–45.5")', price: '£55.00' },
      { name: 'Ruggable rugs (<31.5")', price: '£45.00' },
      { name: 'Settee cushion covers', price: '£10.00' },
      { name: 'Tablecloths', price: '£8.00' },
      { name: 'Curtains', price: '£14.00 / kg' },
    ],
  },
  {
    id: 'garments',
    name: 'Garments',
    items: [
      { name: 'Trousers', price: '£8.50' },
      { name: 'Jeans', price: '£8.50' },
      { name: 'Wool', price: '£8.00' },
      { name: 'Jacket', price: '£10.00' },
      { name: 'Top / Blouse', price: '£5.50' },
      { name: 'Shirts (Press)', price: '£2.00' },
      { name: 'Shirts (Wash & Press)', price: '£4.50' },
      { name: 'Coat (Short)', price: '£15.00' },
      { name: 'Coat (Long)', price: '£20.00' },
      { name: 'Bodywarmer', price: '£10.00' },
      { name: 'Gilet', price: '£30.00' },
      { name: 'Puffa Coat (Short)', price: '£22.50' },
      { name: 'Puffa Coat (Long)', price: '£30.00' },
      { name: '2-Piece Suit', price: '£20.00' },
      { name: '3-Piece Suit', price: '£25.00' },
      { name: 'Skirt', price: '£7.00' },
      { name: 'Dress (Short)', price: '£11.50' },
      { name: 'Dress (Long)', price: '£24.00' },
      { name: 'Tie', price: '£4.00' },
      { name: 'Waistcoat', price: '£5.00' },
    ],
  },
  {
    id: 'services',
    name: 'Wash, Dry & Fold Services',
    items: [
      { name: 'Wash, dry & fold (up to 6kg)', price: '£20.00' },
      { name: 'Wash, steam & fold (up to 6kg)', price: '£28.00' },
      { name: 'Wash, steam & fold (up to 8kg)', price: '£36.00' },
      { name: 'Wash, steam & fold (up to 10kg)', price: '£45.00' },
      { name: 'Extra kg', price: '£4.00' },
    ],
  },
];

export const collectionInfo = {
  local: 'Within 7 mile radius: FREE',
  remote: 'Outside of local area: enquire with our team',
  specialRequest:
    "Don't see your item listed? Reach out to our team for a personalised cleaning enquiry.",
};

// -- How it works --------------------------------------------------------

export const steps = [
  {
    icon: ClipboardList,
    title: 'Book your slot',
    description: 'Complete our short online booking form and tell us what needs cleaning.',
  },
  {
    icon: MapPinned,
    title: 'Drop it off',
    description: 'Bring your items to your nearest drop-off hub, or visit us in store.',
  },
  {
    icon: Wind,
    title: 'We take care of it',
    description: 'Your items are cleaned, restored and finished with proper attention to detail.',
  },
  {
    icon: PackageCheck,
    title: 'Collect & enjoy',
    description: 'Pick up your freshly cleaned items, ready to wear or put straight away.',
  },
];

// -- Drop-off hubs -----------------------------------------------------------
// "store" is our own premises; "partner" hubs are hosted by other local businesses.

function mapsSearchUrl(address: string) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}

export const locations = [
  {
    name: 'Northwich — The Laundry Lounge',
    type: 'store' as const,
    address: '109 Witton St, Northwich, CW9 5DY',
    mapsUrl: mapsSearchUrl('109 Witton St, Northwich, CW9 5DY'),
  },
  {
    name: 'Crewe — Kcutz Barbershop',
    type: 'partner' as const,
    address: '32 Mill St, Crewe, CW2 7AN',
    mapsUrl: mapsSearchUrl('32 Mill St, Crewe, CW2 7AN'),
  },
  {
    name: 'Winsford — Body Tech Gym',
    type: 'partner' as const,
    address: 'Nat Lane Business Park, Unit 9 Nat Ln, Winsford, CW7 3BS',
    mapsUrl: mapsSearchUrl('Nat Lane Business Park, Unit 9 Nat Ln, Winsford, CW7 3BS'),
  },
  {
    name: 'Winsford — Suave Barbers',
    type: 'partner' as const,
    address: '51 Delamere St, Winsford, CW7 2LX',
    mapsUrl: mapsSearchUrl('51 Delamere St, Winsford, CW7 2LX'),
  },
  {
    name: "Nantwich — JW's Hair",
    type: 'partner' as const,
    address: '48 Pillory St, Nantwich, CW5 5BG',
    mapsUrl: mapsSearchUrl('48 Pillory St, Nantwich, CW5 5BG'),
  },
  {
    name: 'Stoke-on-Trent — Tez Xtensions, Chax Barbers (Upstairs)',
    type: 'partner' as const,
    address: '283A Waterloo Road, Corbridge, ST6 3HR',
    mapsUrl: mapsSearchUrl('283A Waterloo Road, Corbridge, ST6 3HR'),
  },
];

export const openingHours = [
  { day: 'Monday', hours: '10:00 – 17:00' },
  { day: 'Tuesday', hours: '10:00 – 18:00' },
  { day: 'Wednesday', hours: '10:00 – 17:00' },
  { day: 'Thursday', hours: '10:00 – 18:00' },
  { day: 'Friday', hours: '10:00 – 17:00' },
  { day: 'Saturday', hours: '10:00 – 14:00' },
  { day: 'Sunday', hours: 'Closed' },
];

export const faqs = [
  {
    question: 'How do I book?',
    answer:
      'Tap any "Book Now" button on this page to complete our short online booking form. Once booked, simply drop your items at your nearest hub, or visit us in store — we\u2019ll do the rest.',
  },
  {
    question: 'What can I drop off at your hubs?',
    answer:
      'Garments, footwear, accessories, bedding and household textiles are all welcome at any of our drop-off hubs across the North West. Larger or unusual items are best brought to our Northwich store.',
  },
  {
    question: 'Is collection or drop-off free?',
    answer:
      'Collection and drop-off is free within a 7 mile radius. Outside of our local area, just get in touch and we\u2019ll be happy to discuss options.',
  },
  {
    question: 'Do you clean footwear, bags and accessories?',
    answer:
      'Yes. Alongside garment care, we clean and restore trainers, boots, designer footwear, handbags, belts, scarves and headwear — see our full price list for details.',
  },
  {
    question: 'Do you clean duvets and bedding?',
    answer:
      'We do. Duvets, bed sets, towels and pillowcases are all cleaned and refreshed, whatever the size or filling.',
  },
  {
    question: "Don't see your item listed?",
    answer:
      'Reach out to our team for a personalised cleaning enquiry — if it needs looking after, we\u2019ll do our best to help.',
  },
];
